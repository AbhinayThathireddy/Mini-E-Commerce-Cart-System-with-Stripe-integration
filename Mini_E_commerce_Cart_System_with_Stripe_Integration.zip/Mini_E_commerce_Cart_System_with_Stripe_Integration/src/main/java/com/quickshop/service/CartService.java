package com.quickshop.service;

import com.quickshop.entity.CartItem;
import com.quickshop.entity.Product;
import com.quickshop.repository.CartItemRepository;
import com.quickshop.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {
    @Autowired
    private CartItemRepository repo;
    @Autowired
    private ProductRepository productRepo;

    public List<CartItem> getCart() {
        return repo.findAll();
    }

    public CartItem addToCart(Long productId, int qty) {
        Product product = productRepo.findById(productId).orElseThrow();
        CartItem item = new CartItem();
        item.setProduct(product);
        item.setQuantity(qty);
        return repo.save(item);
    }

    public void removeFromCart(Long itemId) {
        repo.deleteById(itemId);
    }

    public void updateQuantity(Long itemId, int qty) {
        CartItem item = repo.findById(itemId).orElseThrow();
        item.setQuantity(qty);
        repo.save(item);
    }

    public double getTotal() {
        return repo.findAll().stream()
                .mapToDouble(i -> i.getProduct().getPrice() * i.getQuantity())
                .sum();
    }

    public void clearCart() {
        repo.deleteAll();
    }
}
