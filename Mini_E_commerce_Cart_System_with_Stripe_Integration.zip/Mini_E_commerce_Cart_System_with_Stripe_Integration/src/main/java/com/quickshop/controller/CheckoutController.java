package com.quickshop.controller;

import com.quickshop.entity.CartItem;
import com.quickshop.entity.TransactionLog;
import com.quickshop.exception.CheckoutException;
import com.quickshop.repository.CartItemRepository;
import com.quickshop.repository.TransactionLogRepository;
import com.quickshop.service.EmailService;
import com.quickshop.service.StripeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/checkout")
public class CheckoutController {

    @Autowired
    private StripeService stripeService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private TransactionLogRepository transactionLogRepository;

    @PostMapping("/create-payment-intent")
    public Map<String, String> checkout(@RequestParam String email) {
        // ✅ Calculate total from cart
        Double total = cartItemRepository.getCartTotal();
        if (total == null || total <= 0) {
            throw new CheckoutException("Cart is empty. Please add items before checkout.");
        }

        long amountInCents = (long) (total * 100);  // Stripe expects amount in smallest currency (paise)

        // ✅ Create Stripe Payment Intent
        String clientSecret = stripeService.createPaymentIntent(amountInCents);

        // ✅ Save Transaction Log
        TransactionLog log = new TransactionLog();
        log.setEmail(email);
        log.setAmount(amountInCents);
        log.setStatus("Payment Initiated");
        transactionLogRepository.save(log);

        // ✅ Fetch cart items for detailed invoice
        List<CartItem> items = cartItemRepository.findAll();

        StringBuilder emailBody = new StringBuilder();
        emailBody.append("Thank you for your purchase with QuickShop!\n\n");
        emailBody.append("🛒 Your Order Details:\n");

        for (CartItem item : items) {
            String line = String.format("- %s (Qty: %d) - ₹%.2f\n",
                    item.getProduct().getTitle(),
                    item.getQuantity(),
                    item.getProduct().getPrice() * item.getQuantity());
            emailBody.append(line);
        }

        String formattedTotal = String.format("%.2f", total);

        emailBody.append("\nTotal Amount: ₹").append(formattedTotal);
        emailBody.append("\n\n✅ Your payment is successful.");
        emailBody.append("\n\nVisit again! 🚀");

        // ✅ Send Confirmation Email
        String subject = "QuickShop - Order Confirmation";
        emailService.sendEmail(email, subject, emailBody.toString());

        // ✅ Clear Cart after payment
        cartItemRepository.deleteAll();

        // ✅ Return Stripe client secret to frontend
        Map<String, String> response = new HashMap<>();
        response.put("clientSecret", clientSecret);
        return response;
    }
}
