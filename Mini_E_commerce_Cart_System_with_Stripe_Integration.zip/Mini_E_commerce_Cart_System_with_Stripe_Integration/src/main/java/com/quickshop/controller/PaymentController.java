package com.quickshop.controller;

import com.quickshop.entity.CartItem;
import com.quickshop.repository.CartItemRepository;
import com.stripe.Stripe;
import com.stripe.model.Customer;
import com.stripe.model.checkout.Session;
import com.stripe.param.CustomerCreateParams;
import com.stripe.param.checkout.SessionCreateParams;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    private final CartItemRepository cartItemRepository;

    @Value("${stripe.api.secret}")
    private String stripeSecretKey;

    @Value("${app.base.url}")
    private String baseUrl;

    public PaymentController(CartItemRepository cartItemRepository) {
        this.cartItemRepository = cartItemRepository;
    }

    @PostMapping("/create-checkout-session")
    public Map<String, String> createCheckoutSession(@RequestParam String email) throws Exception {
        Stripe.apiKey = stripeSecretKey;

        List<CartItem> cartItems = cartItemRepository.findAll();

        if (cartItems.isEmpty()) {
            throw new RuntimeException("Cart is empty. Please add items before checkout.");
        }

        // ✅ Create Stripe Customer
        CustomerCreateParams customerParams = CustomerCreateParams.builder()
                .setEmail(email)
                .build();

        Customer customer = Customer.create(customerParams);

        // ✅ Prepare line items for each cart item
        List<SessionCreateParams.LineItem> lineItems = new ArrayList<>();

        for (CartItem item : cartItems) {
            lineItems.add(
                    SessionCreateParams.LineItem.builder()
                            .setQuantity((long) item.getQuantity())
                            .setPriceData(
                                    SessionCreateParams.LineItem.PriceData.builder()
                                            .setCurrency("inr")
                                            .setUnitAmount((long) (item.getProduct().getPrice() * 100)) // price in paise
                                            .setProductData(
                                                    SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                            .setName(item.getProduct().getTitle())
                                                            .setDescription(item.getProduct().getDescription())
                                                            .build()
                                            )
                                            .build()
                            )
                            .build()
            );
        }

        // ✅ Create Checkout Session
        SessionCreateParams params = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl(baseUrl + "/success.html")
                .setCancelUrl(baseUrl + "/cancel.html")
                .setCustomer(customer.getId()) // ✅ Link customer for automatic receipts
                .addAllLineItem(lineItems)
                .build();

        Session session = Session.create(params);

        Map<String, String> response = new HashMap<>();
        response.put("checkoutUrl", session.getUrl());

        return response;
    }
}
