package com.quickshop.controller;

import com.quickshop.entity.CartItem;
import com.quickshop.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService service;

    @GetMapping
    public List<CartItem> viewCart() {
        return service.getCart();
    }

    @PostMapping("/add")
    public CartItem addToCart(@RequestParam Long productId, @RequestParam int qty) {
        return service.addToCart(productId, qty);
    }

    @PutMapping("/update")
    public void update(@RequestParam Long itemId, @RequestParam int qty) {
        service.updateQuantity(itemId, qty);
    }

    @DeleteMapping("/remove/{itemId}")
    public void remove(@PathVariable Long itemId) {
        service.removeFromCart(itemId);
    }

    @GetMapping("/total")
    public double getTotal() {
        return service.getTotal();
    }

    @DeleteMapping("/clear")
    public String clearCart() {
        service.clearCart();
        return "Cart cleared successfully!";
    }
}
