package com.quickshop.repository;

import com.quickshop.entity.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {

    @Query("SELECT SUM(c.product.price * c.quantity) FROM CartItem c")
    Double getCartTotal();

    // Optional: Clear cart after checkout
    void deleteAll();
}
