
CREATE DATABASE IF NOT EXISTS quickshop;
USE quickshop;

-- Product Table
CREATE TABLE IF NOT EXISTS product (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    price DOUBLE NOT NULL,
    image_url VARCHAR(255)
);

-- CartItem Table
CREATE TABLE IF NOT EXISTS cart_item (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    product_id BIGINT,
    quantity INT NOT NULL,
    FOREIGN KEY (product_id) REFERENCES product(id) ON DELETE CASCADE
);

-- Transaction Log Table
CREATE TABLE IF NOT EXISTS transaction_log (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    stripe_payment_id VARCHAR(100),
    email VARCHAR(100),
    amount DOUBLE,
    status VARCHAR(50),
    timestamp DATETIME
);
